import { Tienda } from './Tienda.js';

// Crear objeto Tienda
let miTienda = new Tienda();

// Agregar artículos
miTienda.agregarArticulo(888, 10, 15);
miTienda.agregarArticulo(777, 20, 25);
miTienda.agregarArticulo(999, 15, 25);
miTienda.agregarArticulo(666, 25, 35);
miTienda.agregarArticulo(111, 50, 70);
miTienda.agregarArticulo(333, 40, 50);
miTienda.agregarArticulo(444, 80, 100);
miTienda.agregarArticulo(222, 5, 10);

// Obtener resultados
let resultados = miTienda.obtenerPromedioPrecios();

// Mostrar resultados en HTML
document.getElementById('salida').innerHTML = `
  <h2>Resultados</h2>
  <p>Promedio de los precios de venta: ${resultados.promedioPrecios.toFixed(2)}</p>
  <p>Cantidad de artículos con precio superior a 65$: ${resultados.cantidadArticulosMayoresA65}</p>
`;