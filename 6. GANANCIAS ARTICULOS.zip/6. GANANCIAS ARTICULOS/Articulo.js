export class Articulo {
  constructor(codigo, costo, precioVenta) {
    this.codigo = codigo;
    this.costo = costo;
    this.precioVenta = precioVenta;
  }

  esMayorA65() {
    return this.precioVenta > 65;
  }
}