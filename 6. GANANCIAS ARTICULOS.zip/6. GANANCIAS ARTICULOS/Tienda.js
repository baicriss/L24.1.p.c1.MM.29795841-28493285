import { Articulo } from './Articulo.js';

export class Tienda {
  constructor() {
    this.articulos = [];
  }

  agregarArticulo(codigo, costo, precioVenta) {
    this.articulos.push(new Articulo(codigo, costo, precioVenta));
  }

  obtenerPromedioPrecios() {
    let sumaPrecios = 0;
    let cantidadArticulos = 0;
    let cantidadArticulosMayoresA65 = 0;

    for (let i = 0; i < this.articulos.length; i++) {
      sumaPrecios += this.articulos[i].precioVenta;
      if (this.articulos[i].esMayorA65()) {
        cantidadArticulosMayoresA65++;
      }
    }

    let promedioPrecios = sumaPrecios / this.articulos.length;

    return { promedioPrecios, cantidadArticulosMayoresA65 };
  }
}