import { Empresa } from './Empresa.js';
import { Trabajador } from './Trabajador.js';

let empresa = new Empresa();

let mary = new Trabajador("Mary", 30, 10);
let jose = new Trabajador("José", 35, 5);
let carlos = new Trabajador("Carlos", 35, 0);
let pedro = new Trabajador("Pedro", 25, 10);

empresa.agregarTrabajador(mary);
empresa.agregarTrabajador(jose);
empresa.agregarTrabajador(carlos);
empresa.agregarTrabajador(pedro);

let trabajadorConMenorSalario = empresa.obtenerTrabajadorConMenorSalario();
let montoTotalHorasExtras = empresa.calcularMontoTotalHorasExtras();

document.getElementById('salida').innerHTML = `
  <h2>Resultados</h2>
  <p>Monto total pagado por horas extras: ${montoTotalHorasExtras}$</p>
  <p>Nombre del trabajador con el menor salario obtenido: ${trabajadorConMenorSalario.nombre} con un salario de ${trabajadorConMenorSalario.calcularSalario()}$</p>
`;