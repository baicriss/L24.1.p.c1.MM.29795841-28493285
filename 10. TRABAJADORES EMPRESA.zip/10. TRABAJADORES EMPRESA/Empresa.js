import { Trabajador } from './Trabajador.js';

export class Empresa {
  constructor() {
    this.trabajadores = [];
  }

  agregarTrabajador(trabajador) {
    this.trabajadores.push(trabajador);
  }

  obtenerTrabajadorConMenorSalario() {
    let trabajadorConMenorSalario = null;
    let menorSalario = Infinity;

    for (let i = 0; i < this.trabajadores.length; i++) {
      let trabajadorActual = this.trabajadores[i];
      let salarioActual = trabajadorActual.calcularSalario();

      if (salarioActual < menorSalario) {
        menorSalario = salarioActual;
        trabajadorConMenorSalario = trabajadorActual;
      }
    }

    return trabajadorConMenorSalario;
  }

  calcularMontoTotalHorasExtras() {
    let montoTotal = 0;

    for (let i = 0; i < this.trabajadores.length; i++) {
      let trabajadorActual = this.trabajadores[i];
      montoTotal += trabajadorActual.horasExtra * 25;
    }

    return montoTotal;
  }
}