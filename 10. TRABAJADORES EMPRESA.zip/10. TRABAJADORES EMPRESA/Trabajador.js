export class Trabajador {
    constructor(nombre, horasRegular, horasExtra) {
      this.nombre = nombre;
      this.horasRegular = horasRegular;
      this.horasExtra = horasExtra;
    }
  
    calcularSalario() {
      let salarioRegular = this.horasRegular * 10;
      let salarioExtra = this.horasExtra * 25;
      return salarioRegular + salarioExtra;
    }
  }