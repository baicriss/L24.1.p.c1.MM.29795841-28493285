export class Empleado {
    constructor(nombre, puesto, salario) {
      this.nombre = nombre;
      this.puesto = puesto;
      this.salario = salario;
    }
  }