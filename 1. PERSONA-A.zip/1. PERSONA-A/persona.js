export class Persona {
    constructor(nombre, sexo) {
      this.nombre = nombre;
      this.sexo = sexo;
    }
  }